from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from . import views
urlpatterns = [
    path('', views.userhome, name="userhome"),
    path('test/<int:value>', views.Qustionhome, name="Qustionhome"),
    path('result', views.Result, name="Result"),
    path('showview', views.Fullbiew, name="Fullbiew"),
               ]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)