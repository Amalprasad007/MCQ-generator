from django.shortcuts import render, redirect
from django.contrib import messages
from .genqustion import genqustion
from .forms import MyForm
from django.utils.crypto import get_random_string
from .models import qustion,answer,optionAnser,TestAnswer
# Create your views here.
def userhome(request):
        unicids=get_random_string(length=15)
        testids=get_random_string(length=15)
        request.session['testid']=testids
        if request.method == 'POST':
            request.session['unicids']=unicids
            if  genqustion(request)==1:
                uids=request.session.get('unicids')
                cats=qustion.objects.filter(unicid=uids).all()
                if cats.exists():  # Check if the QuerySet is not empty
                    first_object = cats[0]  # Get the first object
                    first_value = first_object.id  # Replace 'some_field' with your model's field name
                else:
                    first_value = None
                return redirect('Qustionhome',first_value)

        return render(request,'index.html')

def Qustionhome(request,value):
        uids=request.session.get('unicids')
        qstin=qustion.objects.filter(unicid=uids,id=value).values()
        otion=optionAnser.objects.filter(unicid=uids,key=qstin.get()['key']).values()
        answers=answer.objects.filter(unicid=uids,key=qstin.get()['key']).values()
       
        nxtid=get_next_record(request,qstin.get()['id'])

        if request.method == 'POST':
            
                    value1 = request.POST.get('op1')
                    value2 = request.POST.get('answer')
                    value3=""
                    if value1 == value2:
                         value3="true"
                    else:
                         value3="false"
                 
                    TstANser=TestAnswer()
                    TstANser.testkey=request.session.get('testid')
                    TstANser.qustion=request.POST.get('qstin')
                    TstANser.uanswer=value1
                    TstANser.answers=value2
                    TstANser.crect=value3
                    suss= TstANser.save()
                    nextqstin=request.POST.get('nxt')
                    if nextqstin=='None':
                         return redirect('Result')
                    else:
                         return redirect('Qustionhome',nextqstin)
        
        return render(request,'quastion.html',{'q': qstin.all(),'option':otion.all(),'answer':answers.all(),'nctid':nxtid})
    

def get_next_record(request,current_id):
    # Get the current record
    uids=request.session.get('unicids')
    current_record = qustion.objects.filter(unicid=uids,id=current_id,).first()
    if current_record:
        # Get the next record based on the ID
        next_record = qustion.objects.filter(id__gt=current_id).order_by('id').first()
        if next_record:
           return next_record.id
    return None

def Result(request):
        testids=request.session.get('testid')
        filtered_count = TestAnswer.objects.filter(testkey=testids).count()
        crntan=0
        
        queryset= TestAnswer.objects.filter(testkey=testids).all()
        anems=''
        for row in queryset:
           crnt = TestAnswer.objects.filter(testkey=testids,answers=row.answers,uanswer=row.uanswer).count()
           crntan=crntan+crnt
            
        return render(request,'result.html',{'total':filtered_count,'crect':crntan})
def Result(request):
        testids=request.session.get('testid')
        filtered_count = TestAnswer.objects.filter(testkey=testids).count()
        crntan=0
        
        queryset= TestAnswer.objects.filter(testkey=testids).all()
        anems=''
        for item in queryset:
            item.is_equal = item.uanswer == item.answers
            if item.is_equal:
                crntan+=1
        return render(request,'result.html',{'total':filtered_count,'crect':crntan})
    
def Fullbiew(request):
        testids=request.session.get('testid')
        allanswer = TestAnswer.objects.filter(testkey=testids).values()
        queryset= TestAnswer.objects.filter(testkey=testids).all()
        
      
        return render(request,'fullview.html',{'answer':allanswer.all()})